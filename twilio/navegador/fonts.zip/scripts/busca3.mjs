// uso: node busca3.mjs canal "texto" — chama a busca interna do Discord; mostra resposta da rede e o que ficou na loja de resultados
const [ch, q] = process.argv.slice(2);
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const pend = {}, reqs = {};
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id && pend[m.id]) pend[m.id](m); if (m.method === "Network.responseReceived" && /messages\/search/.test(m.params.response.url)) reqs[m.params.requestId] = m.params.response; };
const send = (method, params) => new Promise(r => { const id = ++n; pend[id] = r; ws.send(JSON.stringify({id, method, params})); });
const espera = ms => new Promise(r => setTimeout(r, ms));
await send("Network.enable", {});
const r0 = await send("Runtime.evaluate", {returnByValue: true, expression: `(() => { try { const W = BdApi.Webpack;
  const S = W.getModule(m => m && typeof m.fetchMessages === "function" && typeof m.fetchTabMessages === "function");
  S.fetchMessages({searchContext: {type: "CHANNEL", channelId: ${JSON.stringify(ch)}}, searchQueryString: ${JSON.stringify(q)}, pagination: {offset: 0}, searchMode: "newest", searchEverywhere: false, searchAnalyticsIds: {}});
  return "ok"; } catch (e) { return "erro " + e.message; } })()`});
console.log(r0.result.result.value);
await espera(5000);
for (const [id, resp] of Object.entries(reqs)) {
  const b = await send("Network.getResponseBody", {requestId: id});
  try { const j = JSON.parse(b.result?.body || ""); console.log("REDE", resp.url.split("?")[1]?.slice(0, 50), "tot", j.total_results, JSON.stringify((j.messages || []).flat().slice(0, 12).map(m => m.author?.username + ": " + (m.content || "").slice(0, 25)))); } catch (e) { console.log("REDE ?", resp.status); }
}
const d = await send("Runtime.evaluate", {returnByValue: true, expression: `JSON.stringify((BdApi.Webpack.Stores.SearchMessageStore.getMessages(${JSON.stringify(ch)}) || []).flat().slice(0, 12).map(m => (m.author?.username) + ": " + (m.content || "").slice(0, 25)))`});
console.log("LOJA", d.result.result.value);
process.exit(0);

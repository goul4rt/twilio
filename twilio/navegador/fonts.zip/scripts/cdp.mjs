const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id === 1) { console.log(JSON.stringify(m.result.result?.value ?? m.result, null, 1)); process.exit(0); } };
ws.send(JSON.stringify({id: 1, method: "Runtime.evaluate", params: {expression: process.argv[2], awaitPromise: true, returnByValue: true}}));

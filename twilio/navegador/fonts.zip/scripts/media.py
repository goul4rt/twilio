# uso: python3 -I media.py att media
# Baixa imagens (reduzidas a ~768px) e transcreve áudios com whisper-cli. Retomável.
# Saída: media/img/<key>__<msgid>__<n>.jpg, media/indice.json (contexto de cada item), media/transcricoes.json
import json, os, subprocess, sys, urllib.request
from concurrent.futures import ThreadPoolExecutor

src, out = sys.argv[1], sys.argv[2]
MODEL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "ggml-small.bin")
os.makedirs(f"{out}/img", exist_ok=True)
os.makedirs(f"{out}/aud", exist_ok=True)
IMG = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".heic")

indice, imgs, auds, outros = {}, [], [], {}
for fn in sorted(os.listdir(src)):
    c = json.load(open(os.path.join(src, fn)))
    key = fn[:-5]
    for m in c.get("att") or []:
        for n, a in enumerate(m["a"]):
            item = f"{key}__{m['id']}__{n}"
            ct, name = a.get("ct", ""), (a.get("fn") or "").lower()
            indice[item] = {"ch": c["ch"], "msg": m["id"], "quem": m["quem"], "ts": m["ts"], "texto": m["texto"], "fn": a.get("fn"), "ct": ct}
            if ct.startswith("image/") or name.endswith(IMG):
                imgs.append((item, a))
            elif ct.startswith("video/") or name.endswith((".mp4", ".mov", ".webm")):
                imgs.append((item, a))
                auds.append((item, a))
            elif ct.startswith("audio/") or name.endswith((".ogg", ".mp3", ".m4a", ".wav", ".opus")):
                auds.append((item, a))
            else:
                outros[ct or name.rsplit(".", 1)[-1]] = outros.get(ct or name.rsplit(".", 1)[-1], 0) + 1
json.dump(indice, open(f"{out}/indice.json", "w"))
print(len(imgs), "imagens,", len(auds), "áudios; outros tipos:", dict(sorted(outros.items(), key=lambda x: -x[1])[:8]))

def get(url, path):
    subprocess.run(["curl", "-fsSL", "--max-time", "120", "-A", "Mozilla/5.0", "-o", path, url], check=True, capture_output=True)

falhas = []
def baixa_img(t):
    item, a = t
    dst = f"{out}/img/{item}.jpg"
    if os.path.exists(dst):
        return
    url = (a.get("proxy") or a["url"])
    url += ("&" if "?" in url else "?") + "width=768&height=768&format=jpeg"
    try:
        get(url, dst)
    except Exception as e:
        try:  # sem proxy: baixa original e reduz com sips
            raw = dst + ".raw"
            get(a["url"], raw)
            subprocess.run(["sips", "-s", "format", "jpeg", "-Z", "768", raw, "--out", dst], capture_output=True)
            os.remove(raw)
        except Exception as e2:
            falhas.append((item, str(e2)[:80]))

with ThreadPoolExecutor(8) as ex:
    list(ex.map(baixa_img, imgs))
print("imagens baixadas:", len(os.listdir(f"{out}/img")), "falhas:", len(falhas))

trans_path = f"{out}/transcricoes.json"
trans = json.load(open(trans_path)) if os.path.exists(trans_path) else {}
trans = {k: v for k, v in trans.items() if not v.startswith("[falha")}  # tenta de novo as que falharam
for item, a in auds:
    if item in trans:
        continue
    raw, wav = f"{out}/aud/{item}.src", f"{out}/aud/{item}.wav"
    try:
        get(a["url"], raw)
        f = subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", raw, "-ar", "16000", "-ac", "1", wav], capture_output=True, text=True)
        if f.returncode and "does not contain any stream" in f.stderr:
            trans[item] = "[sem fala]"  # vídeo sem trilha de áudio
            raise StopIteration
        f.check_returncode()
        r =subprocess.run(["whisper-cli", "-m", MODEL, "-l", "pt", "-nt", "-np", "-f", wav], capture_output=True, text=True, timeout=600)
        trans[item] = r.stdout.strip().replace("\n", " ") or "[sem fala]"
    except StopIteration:
        pass
    except Exception as e:
        trans[item] = f"[falha: {str(e)[:60]}]"
    for p in (raw, wav):
        if os.path.exists(p):
            os.remove(p)
    json.dump(trans, open(trans_path, "w"))
print("áudios transcritos:", len(trans))
for f in falhas[:10]:
    print("FALHA", f)

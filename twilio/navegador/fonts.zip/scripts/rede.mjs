// uso: node rede.mjs "texto" — faz a busca e mostra as respostas de /search capturadas na rede (via CDP)
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const pend = {}, reqs = {};
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id && pend[m.id]) pend[m.id](m); if (m.method === "Network.responseReceived" && /search/.test(m.params.response.url)) reqs[m.params.requestId] = m.params.response; };
const send = (method, params) => new Promise(r => { const id = ++n; pend[id] = r; ws.send(JSON.stringify({id, method, params})); });
const espera = ms => new Promise(r => setTimeout(r, ms));
await send("Network.enable", {});
const r = await send("Runtime.evaluate", {returnByValue: true, expression: `(() => { const i = document.querySelector('[role=combobox][contenteditable=true]') || document.querySelector('[class*=search] [contenteditable=true]'); if (!i) return 'sem caixa'; document.querySelector('[aria-label=Limpar]')?.click(); return 'ok'; })()`});
await espera(800);
await send("Runtime.evaluate", {expression: `(document.querySelector('[role=combobox][contenteditable=true]') || document.querySelector('[class*=search] [contenteditable=true]')).focus()`});
await espera(400);
await send("Input.insertText", {text: process.argv[2]});
await espera(600);
await send("Input.dispatchKeyEvent", {type: "rawKeyDown", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13});
await send("Input.dispatchKeyEvent", {type: "keyUp", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13});
await espera(5000);
for (const [id, resp] of Object.entries(reqs)) {
  const b = await send("Network.getResponseBody", {requestId: id});
  let body = b.result?.body || ""; let info;
  try { const j = JSON.parse(body); info = {tot: j.total_results, n: j.messages?.length, ex: (j.messages || []).flat().slice(0, 3).map(m => m.author?.username + ": " + (m.content || "").slice(0, 25))}; } catch { info = body.slice(0, 150); }
  console.log(resp.status, resp.url.replace(/^https:\/\/[^/]+/, "").slice(0, 160), JSON.stringify(info));
}
process.exit(0);

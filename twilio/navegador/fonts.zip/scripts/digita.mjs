// uso: node digita.mjs "texto" — foca a caixa de busca e digita (sem Enter), via CDP
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const pend = {};
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id && pend[m.id]) pend[m.id](m); };
const send = (method, params) => new Promise(r => { const id = ++n; pend[id] = r; ws.send(JSON.stringify({id, method, params})); });
const espera = ms => new Promise(r => setTimeout(r, ms));
await send("Runtime.evaluate", {expression: `document.querySelector('[aria-label=Limpar]')?.click()`});
await espera(600);
await send("Runtime.evaluate", {expression: `(document.querySelector('[role=combobox][contenteditable=true]') || document.querySelector('[class*=search] [contenteditable=true]'))?.click()`});
await espera(600);
for (const ch of process.argv[2]) { await send("Input.dispatchKeyEvent", {type: "keyDown", text: ch, key: ch, unmodifiedText: ch}); await send("Input.dispatchKeyEvent", {type: "keyUp", key: ch}); await espera(80); }
await espera(2500);
process.exit(0);

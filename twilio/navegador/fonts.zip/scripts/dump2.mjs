// Amigos sem conversa aberta: abre a DM, baixa o histórico e fecha de novo (fechar não apaga nada).
import fs from "fs";
const out = process.argv[2];
const EXCL = ["1343940826375389209", "814858225287299163", "1374034229297676411", "821470975756992592"];
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const pend = {};
ws.onmessage = e => { const m = JSON.parse(e.data); pend[m.id]?.(m); };
const ev = expr => new Promise(r => { const id = ++n; pend[id] = m => r(m.result?.result?.value ?? {erro: m.result?.exceptionDetails?.exception?.description ?? "?"}); ws.send(JSON.stringify({id, method: "Runtime.evaluate", params: {expression: expr, awaitPromise: true, returnByValue: true}})); });
const amigos = await ev(`(() => {
  const St = BdApi.Webpack.Stores;
  const abertos = new Set(Object.values(St.ChannelStore.getMutablePrivateChannels()).filter(c => c.type === 1).flatMap(c => c.recipients));
  return St.RelationshipStore.getFriendIDs().filter(id => !abertos.has(id) && !${JSON.stringify(EXCL)}.includes(id));
})()`);
console.log(amigos.length, "amigos sem conversa aberta");
for (const uid of amigos) {
  const f = `${out}/${uid}.json`;
  if (fs.existsSync(f)) continue;
  const r = await ev(`(async () => {
    const W = BdApi.Webpack, St = W.Stores;
    const PC = W.getModule(m => m?.getOrEnsurePrivateChannel && m?.closePrivateChannel);
    const MA = W.getModule(W.Filters.byKeys("fetchMessages", "sendMessage"));
    const u = St.UserStore.getUser(${JSON.stringify(uid)});
    const nome = (u?.globalName || "") + "/" + u?.username;
    let ch;
    try { ch = await PC.getOrEnsurePrivateChannel(${JSON.stringify(uid)}); } catch (e) { return {erro: "abrir: " + (e?.status ?? e?.message ?? e)}; }
    try {
      await MA.fetchMessages({channelId: ch, limit: 100});
      for (let i = 0; i < 400; i++) {
        const m = St.MessageStore.getMessages(ch);
        if (!m.hasMoreBefore || !m._array.length) break;
        await MA.fetchMessages({channelId: ch, limit: 100, before: m._array[0].id});
        await new Promise(r => setTimeout(r, 700));
      }
      const m = St.MessageStore.getMessages(ch), me = St.UserStore.getCurrentUser().id;
      return {ch, nomes: nome, type: 1, incompleto: m.hasMoreBefore, rows: m._array.map(x => [x.id, x.author.id === me ? "E" : (x.author.globalName || x.author.username), new Date(x.timestamp).toISOString().slice(2,10), x.content, x.attachments?.length || 0])};
    } finally {
      try { PC.closePrivateChannel(ch); } catch {}
    }
  })()`);
  if (r.erro) { console.log("PAROU", uid, r.erro); break; }
  fs.writeFileSync(f, JSON.stringify(r));
  console.log(uid, r.nomes?.slice(0, 40), r.rows.length + (r.incompleto ? " (incompleto)" : ""));
  await new Promise(r => setTimeout(r, 4000));
}
console.log("FIM");
process.exit(0);

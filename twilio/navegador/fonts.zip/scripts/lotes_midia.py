# uso: python3 -I lotes_midia.py media
# Monta lotes de ~30 imagens (com contexto) e um texto com as transcrições, para os agentes.
import json, os, sys

m = sys.argv[1]
idx = json.load(open(f"{m}/indice.json"))
imgs = sorted(f[:-4] for f in os.listdir(f"{m}/img") if f.endswith(".jpg") and os.path.getsize(f"{m}/img/{f}") > 500)
os.makedirs(f"{m}/lotes", exist_ok=True)
# incremental: itens já postos em lotes não mudam de lote; os novos vão para lotes novos
feitos, ult = set(), {"L": 0, "A": 0}
for fn in os.listdir(f"{m}/lotes"):
    if fn[0] in "LA" and fn.endswith(".txt"):
        ult[fn[0]] = max(ult[fn[0]], int(fn[1:4]))
        feitos |= {l.split("|")[0] for l in open(f"{m}/lotes/{fn}") if l.strip()}
imgs = [i for i in imgs if i not in feitos]
N = 30
lotes = [imgs[i:i + N] for i in range(0, len(imgs), N)]
for k, lote in enumerate(lotes, ult["L"]):
    with open(f"{m}/lotes/L{k + 1:03d}.txt", "w") as f:
        for it in lote:
            v = idx[it]
            tipo = "quadro de vídeo" if v["ct"].startswith("video/") else "imagem"
            f.write(f"{it}|{v['quem']}|{v['ts']}|{tipo}|{m}/img/{it}.jpg|texto da msg: {v['texto'][:150]}\n")
tr = json.load(open(f"{m}/transcricoes.json")) if os.path.exists(f"{m}/transcricoes.json") else {}
aud, cur = [], ""
for it, t in sorted(tr.items()):
    if t.startswith("[falha") or t == "[sem fala]" or it in feitos:
        continue
    v = idx[it]
    line = f"{it}|{v['quem']}|{v['ts']}|{'vídeo' if v['ct'].startswith('video/') else 'áudio'}|texto da msg: {v['texto'][:150]}|transcrição: {t[:1500]}\n"
    if len(cur) + len(line) > 40000:
        aud.append(cur); cur = ""
    cur += line
aud += [cur] if cur else []
for k, a in enumerate(aud, ult["A"]):
    open(f"{m}/lotes/A{k + 1:03d}.txt", "w").write(a)
print(len(imgs), "imagens em", len(lotes), "lotes;", sum(1 for t in tr.values() if not t.startswith("[")), "transcrições com fala")

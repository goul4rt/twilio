// uso: node foto.mjs saida.png — screenshot da janela do Twilio via CDP
import fs from "fs";
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id === 1) { fs.writeFileSync(process.argv[2], Buffer.from(m.result.data, "base64")); process.exit(0); } };
ws.send(JSON.stringify({id: 1, method: "Page.captureScreenshot", params: {format: "png"}}));

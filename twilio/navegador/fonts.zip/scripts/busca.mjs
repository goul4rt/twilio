// uso: node busca.mjs "texto" — limpa a caixa de busca do Discord, digita o texto e Enter (via CDP)
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const send = (method, params) => new Promise(r => { const id = ++n; ws.addEventListener("message", e => { const m = JSON.parse(e.data); if (m.id === id) r(m); }); ws.send(JSON.stringify({id, method, params})); });
const espera = ms => new Promise(r => setTimeout(r, ms));
const r = await send("Runtime.evaluate", {returnByValue: true, expression: `(() => { const i = document.querySelector('[role=combobox][contenteditable=true]') || document.querySelector('[class*=search] [contenteditable=true]'); if (!i) return 'sem caixa'; i.focus(); document.execCommand('selectAll'); document.execCommand('delete'); return 'ok'; })()`});
console.log(r.result.result.value);
await espera(400);
await send("Input.insertText", {text: process.argv[2]});
await espera(600);
await send("Input.dispatchKeyEvent", {type: "rawKeyDown", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13});
await send("Input.dispatchKeyEvent", {type: "keyUp", key: "Enter", code: "Enter", windowsVirtualKeyCode: 13});
await espera(4000);
process.exit(0);

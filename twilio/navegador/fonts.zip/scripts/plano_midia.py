# uso: python3 -I plano_midia.py media > plano_midia.json
# Junta res_*.json dos lotes de mídia; só aceita item que estava no próprio lote. Esconde a mensagem inteira.
import json, os, sys

m = sys.argv[1]
idx = json.load(open(f"{m}/indice.json"))
hidden, erros = {}, []
for fn in sorted(os.listdir(f"{m}/lotes")):
    if not fn.startswith("res_"):
        continue
    lote = open(f"{m}/lotes/{fn[4:-5]}.txt").read()
    try:
        r = json.load(open(f"{m}/lotes/{fn}"))
    except Exception as e:
        erros.append((fn, str(e)[:60])); continue
    for e in r.get("esconder", []):
        it = e.get("item", "")
        if it not in idx or f"{it}|" not in lote:
            erros.append((fn, f"item fora do lote: {it[:50]}")); continue
        v = idx[it]
        hidden[v["msg"]] = {"ch": v["ch"], "quem": v["quem"], "texto": (v["texto"] or f"[{v['fn']}]")[:80], "motivo": e.get("motivo", "")[:80]}
print(json.dumps({"hidden": hidden, "edited": {}, "forcar": True}))
print(len(hidden), "mensagens com mídia a esconder,", len(erros), "erros", file=sys.stderr)
for e in erros[:20]:
    print("ERRO", e, file=sys.stderr)


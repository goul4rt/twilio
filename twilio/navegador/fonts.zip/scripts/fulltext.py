# uso: python3 -I fulltext.py saida_dir dm dm2
# Texto completo de todas as conversas, em partes de ~40KB com cabeçalho do canal em cada parte.
import json, os, sys

out, dirs = sys.argv[1], sys.argv[2:]
LIM = 40000
os.makedirs(out, exist_ok=True)
parts, cur = [], ""
total = 0
for d in dirs:
    for fn in sorted(os.listdir(d)):
        c = json.load(open(os.path.join(d, fn)))
        rows = c.get("rows")
        key = fn[:-5]
        if not rows or (c.get("ch") or key) == "1519340438241148951":  # carmona001 já lida inteira
            continue
        head = f"=== CANAL {key} | {c.get('nomes', '')} | {len(rows)} msgs ==="
        cur += ("\n" if cur else "") + head
        for i, (mid, who, ts, txt, att) in enumerate(rows):
            txt = (txt or "").replace("\n", " / ")
            if not txt and not att:
                continue
            if att:
                txt += f" [anexo x{att}]"
            line = f"\n{key}:{i}|{who}|{ts}|{txt[:600]}"
            if len(cur) + len(line) > LIM:
                parts.append(cur)
                cur = head + " (cont.)"
            cur += line
            total += 1
if cur:
    parts.append(cur)
for i, p in enumerate(parts):
    open(os.path.join(out, f"t{i + 1:03d}.txt"), "w").write(p)
print(total, "mensagens em", len(parts), "partes")

// uso: node busca2.mjs canal "texto" — dispara a busca do Discord pela ação interna e mostra a resposta da rede + o que sobra depois do plugin
const [ch, q] = process.argv.slice(2);
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const pend = {}, reqs = {};
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id && pend[m.id]) pend[m.id](m); if (m.method === "Network.responseReceived" && /messages\/search/.test(m.params.response.url)) reqs[m.params.requestId] = m.params.response; };
const send = (method, params) => new Promise(r => { const id = ++n; pend[id] = r; ws.send(JSON.stringify({id, method, params})); });
const espera = ms => new Promise(r => setTimeout(r, ms));
await send("Network.enable", {});
await send("Runtime.evaluate", {expression: `(() => { const D = BdApi.Plugins.get("ApagarLocal").instance.Dispatcher; window.__depois = null;
  const f = a => { window.__depois = (a.data?.[0]?.messages || []).flat().filter(m => m.hit).map(m => m.author?.username + ": " + (m.content || "").slice(0, 25)); };
  D.subscribe("SEARCH_MESSAGES_SUCCESS", f); setTimeout(() => D.unsubscribe("SEARCH_MESSAGES_SUCCESS", f), 8000);
  D.dispatch({type: "SEARCH_RESULTS_QUERY_UPDATE", id: ${JSON.stringify(ch)}, queryString: ${JSON.stringify(q)}, query: {content: ${JSON.stringify(q)}, sort_by: "timestamp", sort_order: "desc", offset: 0}, offset: 0}); })()`});
await espera(5000);
for (const [id, resp] of Object.entries(reqs)) {
  const b = await send("Network.getResponseBody", {requestId: id});
  try { const j = JSON.parse(b.result?.body || ""); console.log("REDE", resp.url.split("?")[1]?.slice(0, 60), "tot", j.total_results, (j.messages || []).flat().filter(m => m.hit !== false).slice(0, 12).map(m => m.author?.username + ": " + (m.content || "").slice(0, 25))); } catch (e) { console.log("REDE ?", resp.status); }
}
const d = await send("Runtime.evaluate", {returnByValue: true, expression: "JSON.stringify(window.__depois)"});
console.log("DEPOIS DO PLUGIN", d.result.result.value);
process.exit(0);

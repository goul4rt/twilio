// uso: node bidi.mjs url saida.png — navega num Firefox (WebDriver BiDi na 9334) e mostra a URL final + screenshot
import fs from "fs";
const ws = new WebSocket("ws://127.0.0.1:9334/session");
await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
let n = 0; const pend = {};
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id && pend[m.id]) pend[m.id](m); };
const send = (method, params = {}) => new Promise(r => { const id = ++n; pend[id] = r; ws.send(JSON.stringify({id, method, params})); });
const espera = ms => new Promise(r => setTimeout(r, ms));
await send("session.new", {capabilities: {}});
const tree = await send("browsingContext.getTree", {});
const context = tree.result.contexts[0].context;
await send("browsingContext.navigate", {context, url: process.argv[2], wait: "none"});
await espera(7000);
const t2 = await send("browsingContext.getTree", {});
console.log(process.argv[2], "->", t2.result.contexts[0].url);
const shot = await send("browsingContext.captureScreenshot", {context});
if (shot.result?.data) fs.writeFileSync(process.argv[3], Buffer.from(shot.result.data, "base64"));
process.exit(0);

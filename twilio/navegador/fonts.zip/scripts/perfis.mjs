// uso: node perfis.mjs saida.json — lê pronomes/bio de amigos + contatos de DM (só leitura)
import fs from "fs";
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
ws.onmessage = e => { const m = JSON.parse(e.data); console.log(m.result?.result?.value ?? JSON.stringify(m).slice(0, 300)); fs.writeFileSync(process.argv[2], m.result?.result?.value ?? "[]"); process.exit(0); };
ws.send(JSON.stringify({id: 1, method: "Runtime.evaluate", params: {awaitPromise: true, returnByValue: true, expression: `(async () => {
  const W = BdApi.Webpack, St = W.Stores;
  const f = W.getModule(m => typeof m === "function" && m.toString().includes("USER_PROFILE_FETCH_START"), {searchExports: true});
  const amigos = new Set(St.RelationshipStore.getFriendIDs()), ids = new Set(amigos);
  Object.values(St.ChannelStore.getMutablePrivateChannels()).forEach(c => c.recipients.forEach(u => ids.add(u)));
  ["757061014444441610", "1200132188331585639"].forEach(u => ids.add(u));
  const out = [];
  for (const id of ids) {
    const u = St.UserStore.getUser(id);
    if (u?.bot) continue;
    let p = St.UserProfileStore.getUserProfile(id);
    if (!p?.fetchEndedAt) { try { await f(id, {withMutualGuilds: false}); } catch (e) {} await new Promise(r => setTimeout(r, 1500)); p = St.UserProfileStore.getUserProfile(id); }
    out.push({id, user: u?.username, nome: u?.globalName, amigo: amigos.has(id), pron: p?.pronouns || "", bio: (p?.bio || "").replace(/\\n/g, " ").slice(0, 120)});
  }
  return JSON.stringify(out);
})()`}}));

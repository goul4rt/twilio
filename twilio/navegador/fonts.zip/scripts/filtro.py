# uso: python3 -I filtro.py dm/ saida.txt
# Junta, de todas as conversas, as janelas em volta de mensagens com termos suspeitos.
import json, os, re, sys, unicodedata

TERMOS = r"""te amo|amo (vc|voce|tu)|te adoro|\bbb\b|\bbebe\b|gat[aã]o|gatinh|\blind[oa]|\bfof[oa]|beij|bunda|\brabo\b|peit|gostos|safad|tes[aã]o|nude|pelad|saudade|casad|solteir|namor|esposa|\bmuie|crush|paquer|\bamor|paix|ciume|\bs2\b|corao|cora[cç][aã]o|sexo|transa|trepa|fode|\bpau\b|pinto|piroca|buceta|xota|goza|chupa|motel|escondid|segredo|ninguem sabe|nao conta|\b69\b|danad|delicia|seduz|sensual|carinho|her[oó]i|princes|meu bem|querid|minha vida|moz[aã]o|amorzinho|\bmo\b|ficar com|pegar (vc|voce|tu)|te pegar|cheiro|abraç|abrac|dormir junto|vem (aqui|pra ca|morar)"""
EMOJI = "❤💋😘😍🥰💕💖💗💓💞😚😻🍑🍆💦🔥😏"
rx = re.compile(TERMOS, re.I)
norm = lambda s: unicodedata.normalize("NFD", s).encode("ascii", "ignore").decode().lower()
CTX = 3

src, out = sys.argv[1], sys.argv[2]
total = flag = 0
with open(out, "w") as f:
    for fn in sorted(os.listdir(src)):
        d = json.load(open(os.path.join(src, fn)))
        rows = d.get("rows")
        if not rows:
            continue
        ch = fn[:-5]
        if ch == "1519340438241148951":  # carmona001 já foi revisada à mão
            continue
        total += len(rows)
        hits = [i for i, r in enumerate(rows) if rx.search(r[3] or "") or rx.search(norm(r[3] or "")) or any(e in (r[3] or "") for e in EMOJI)]
        if not hits:
            continue
        keep = sorted({j for i in hits for j in range(max(0, i - CTX), min(len(rows), i + CTX + 1))})
        f.write(f"\n=== CANAL {ch} | {d.get('nomes','')} | {len(rows)} msgs ===\n")
        prev = None
        for j in keep:
            if prev is not None and j != prev + 1:
                f.write("...\n")
            mid, who, ts, c, att = rows[j]
            c = (c or "").replace("\n", " / ")
            if att:
                c += f" [anexo x{att}]"
            f.write(f"{ch}:{j}|{who}|{ts}|{c}\n")
            prev = j
            flag += 1
print(f"{total} mensagens no total, {flag} linhas nas janelas")

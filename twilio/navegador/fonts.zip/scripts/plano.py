# uso: python3 -I plano.py resultados.json dm dm2 > plano.json
# resultados.json = lista com os JSON devolvidos pelos agentes. Converte "canal:indice" em ids de mensagem.
import html, json, os, sys

res = json.load(open(sys.argv[1]))
convs = {}
for d in sys.argv[2:]:
    for fn in os.listdir(d):
        c = json.load(open(os.path.join(d, fn)))
        if c.get("rows"):
            convs[fn[:-5]] = c  # nome do arquivo (id do canal em dm/, id do amigo em dm2/)

hidden, edited, erros = {}, {}, []
def pega(ref):
    key, i = ref.split(":")
    c = convs[key]
    return c.get("ch") or key, c["rows"][int(i)]

import re
normt = lambda s: re.sub(r"\W+", " ", html.unescape(s or "").lower()).strip()

def confere(g):
    """Grupo só passa se a citação aparece nas mensagens; senão tenta achar o trecho certo a ±5 e desloca."""
    cit = g.get("cit")
    if not cit:
        return g["ids"]
    frags = [normt(x) for x in re.split(r" / |\.\.\.", html.unescape(cit)) if normt(x)]
    key = g["ids"][0].split(":")[0]
    rows = convs.get(key, {}).get("rows", [])
    idx = [int(x.split(":")[1]) for x in g["ids"]]
    emo = [ch for ch in html.unescape(cit) if ord(ch) > 0x2000 and not ch.isalnum()]  # citação só de emoji
    def ok(ii):
        if not all(0 <= i < len(rows) for i in ii):
            return False
        if frags:
            return any(f in " ".join(normt(rows[i][3]) for i in ii) for f in frags)
        return any(e in "".join(rows[i][3] or "" for i in ii) for e in emo)
    for d in [0, 1, -1, 2, -2, 3, -3, 4, -4, 5, -5]:
        ii = [i + d for i in idx]
        if ok(ii):
            return [f"{key}:{i}" for i in ii]
    erros.append((g["ids"][0], f"citação não encontrada: {cit[:40]!r}"))
    return []

for r in res:
    for g in r.get("esconder", []):
        for ref in confere(g):
            try:
                ch, (mid, who, ts, c, att) = pega(ref)
                hidden[mid] = {"ch": ch, "quem": who, "texto": (c or "")[:80]}
            except Exception as e:
                erros.append((ref, str(e)))
    for e in r.get("editar", []):
        try:
            ch, (mid, who, ts, c, att) = pega(e["id"])
            de, para = html.unescape(e["de"]).strip(), html.unescape(e["para"])
            if "\n" in (c or ""):
                para = para.replace(" / ", "\n")
            e["para"] = para
            flat = lambda t: (t or "").replace("\n", " / ").strip()
            if flat(c) != de:
                # índice deslocado: procura o texto exato nas vizinhas
                chn, i = e["id"].split(":")
                rows = convs[chn]["rows"]
                viz = [j for j in range(max(0, int(i) - 5), min(len(rows), int(i) + 6)) if flat(rows[j][3]) == de]
                if viz:
                    mid, who, ts, c, att = rows[viz[0]]
                elif flat(c).startswith(de):
                    # agente citou só o começo de uma mensagem longa: troca só o começo
                    cut = len(de.replace(" / ", "\n")) if "\n" in c else len(de)
                    para = para + c[cut:]
                    e["para"] = para
                else:
                    erros.append((e["id"], f"texto não bate: {c[:60]!r} vs {e['de'][:60]!r}"))
                    continue
            if not e["para"].strip():
                hidden[mid] = {"ch": ch, "quem": who, "texto": (c or "")[:80]}
                continue
            edited[mid] = {"ch": ch, "quem": who, "texto": (c or "")[:80], "original": c, "novo": e["para"]}
        except Exception as ex:
            erros.append((e["id"], str(ex)))

for mid in edited:
    hidden.pop(mid, None)  # editar ganha de esconder
print(json.dumps({"hidden": hidden, "edited": edited}))
print(len(hidden), "esconder,", len(edited), "editar,", len(erros), "erros", file=sys.stderr)
for e in erros[:20]:
    print("ERRO", e, file=sys.stderr)

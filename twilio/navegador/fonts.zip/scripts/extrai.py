# uso: python3 -I extrai.py <agent.output jsonl> <saida.json>  — pega o último JSON {"esconder"...} do agente
import json, re, sys
txt = None
for line in open(sys.argv[1]):
    try:
        o = json.loads(line)
    except Exception:
        continue
    msg = o.get("message") or {}
    if msg.get("role") != "assistant":
        continue
    c = msg.get("content")
    parts = [c] if isinstance(c, str) else [p.get("text", "") for p in c or [] if isinstance(p, dict) and p.get("type") == "text"]
    for p in parts:
        if '"esconder"' in p:
            txt = p
s = txt[txt.index("{"): txt.rindex("}") + 1]
d = json.loads(s)
json.dump(d, open(sys.argv[2], "w"))
print(sys.argv[2], len(d["esconder"]), "grupos,", len(d["editar"]), "edições")

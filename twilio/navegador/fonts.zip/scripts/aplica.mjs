// uso: node aplica.mjs plano.json — junta hidden/edited no plugin ApagarLocal e salva
import fs from "fs";
const plano = fs.readFileSync(process.argv[2], "utf8");
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id === 1) { console.log(JSON.stringify(m.result.result?.value ?? m.result)); process.exit(0); } };
ws.send(JSON.stringify({id: 1, method: "Runtime.evaluate", params: {returnByValue: true, expression: `(() => {
  const p = ${plano};
  const inst = BdApi.Plugins.get("ApagarLocal").instance;
  const antes = [Object.keys(inst.hidden).length, Object.keys(inst.edited).length];
  for (const id of p.remover || []) delete inst.hidden[id];
  for (const [id, v] of Object.entries(p.edited)) { if (!inst.edited[id]) inst.edited[id] = v; delete inst.hidden[id]; }
  for (const [id, v] of Object.entries(p.hidden)) { if (p.forcar && inst.edited[id]) inst.restoreEdit(id); if (!inst.edited[id]) inst.hidden[id] = v; }
  inst.save();
  const salvo = [Object.keys(BdApi.Data.load("ApagarLocal", "hidden")).length, Object.keys(BdApi.Data.load("ApagarLocal", "edited")).length];
  return {antes, depois: [Object.keys(inst.hidden).length, Object.keys(inst.edited).length], salvo};
})()`}}));

// uso: node dump.mjs canais.json outdir
import fs from "fs";
const [,, canaisFile, out] = process.argv;
const EXCL = ["1343940826375389209", "814858225287299163", "1374034229297676411", "821470975756992592"]; // seraphine + candidatos azulirio
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const pend = {};
ws.onmessage = e => { const m = JSON.parse(e.data); pend[m.id]?.(m); };
const ev = expr => new Promise(r => { const id = ++n; pend[id] = m => r(m.result?.result?.value ?? m.result ?? m); ws.send(JSON.stringify({id, method: "Runtime.evaluate", params: {expression: expr, awaitPromise: true, returnByValue: true}})); });
const canais = JSON.parse(fs.readFileSync(canaisFile)).rows.filter(c => !c.bot);
for (const c of canais) {
  const f = `${out}/${c.id}.json`;
  if (fs.existsSync(f)) continue;
  const r = await ev(`(async () => {
    const W = BdApi.Webpack, St = W.Stores, ch = ${JSON.stringify(c.id)}, EXCL = ${JSON.stringify(EXCL)};
    const chan = St.ChannelStore.getChannel(ch);
    if (chan.recipients.some(u => EXCL.includes(u))) return {skip: "excluido"};
    const MA = W.getModule(W.Filters.byKeys("fetchMessages", "sendMessage"));
    await MA.fetchMessages({channelId: ch, limit: 100});
    for (let i = 0; i < 400; i++) {
      const m = St.MessageStore.getMessages(ch);
      if (!m.hasMoreBefore || !m._array.length) break;
      await MA.fetchMessages({channelId: ch, limit: 100, before: m._array[0].id});
      await new Promise(r => setTimeout(r, 700));
    }
    const m = St.MessageStore.getMessages(ch), me = St.UserStore.getCurrentUser().id;
    return {nomes: ${JSON.stringify(c.nomes)}, type: chan.type, incompleto: m.hasMoreBefore, rows: m._array.map(x => [x.id, x.author.id === me ? "E" : (x.author.globalName || x.author.username), new Date(x.timestamp).toISOString().slice(2,10), x.content, x.attachments?.length || 0])};
  })()`);
  fs.writeFileSync(f, JSON.stringify(r));
  console.log(c.id, c.nomes.slice(0, 40), r.skip ?? (r.rows?.length + (r.incompleto ? " (incompleto)" : "")));
  await new Promise(r => setTimeout(r, 1500));
}
console.log("FIM");
process.exit(0);

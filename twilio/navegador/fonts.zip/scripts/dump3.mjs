// uso: node dump3.mjs outdir — levanta os anexos (imagem/áudio) de todas as conversas pessoais e de amigos.
// Abre DM de amigo sem conversa aberta e fecha de novo. Retomável: pula quem já tem arquivo.
import fs from "fs";
const out = process.argv[2];
const EXCL = ["1343940826375389209", "821470975756992592", "814858225287299163", "1374034229297676411"]; // seraphine, azurilio, candidatos
const list = await (await fetch("http://localhost:9229/json")).json();
const ws = new WebSocket(list.find(t => t.type === "page").webSocketDebuggerUrl);
await new Promise(r => ws.onopen = r);
let n = 0; const pend = {};
ws.onmessage = e => { const m = JSON.parse(e.data); pend[m.id]?.(m); };
ws.onclose = () => { console.log("WS FECHOU"); process.exit(2); };
const ev = expr => new Promise(r => { const id = ++n; pend[id] = m => r(m.result?.result?.value ?? {erro: m.result?.exceptionDetails?.exception?.description ?? "?"}); ws.send(JSON.stringify({id, method: "Runtime.evaluate", params: {expression: expr, awaitPromise: true, returnByValue: true}})); });

const alvos = await ev(`(() => {
  const St = BdApi.Webpack.Stores, EX = ${JSON.stringify(EXCL)};
  const chans = Object.values(St.ChannelStore.getMutablePrivateChannels()).filter(c => !(c.rawRecipients||[]).some(r => r.bot) && !c.recipients.some(u => EX.includes(u)));
  const abertos = new Set(chans.filter(c => c.type === 1).flatMap(c => c.recipients));
  return [...chans.map(c => ({key: c.id, ch: c.id})), ...St.RelationshipStore.getFriendIDs().filter(u => !abertos.has(u) && !EX.includes(u)).map(u => ({key: u, user: u}))];
})()`);
console.log(alvos.length, "conversas");
for (const a of alvos) {
  const f = `${out}/${a.key}.json`;
  if (fs.existsSync(f)) continue;
  const r = await ev(`Promise.race([new Promise(r => setTimeout(() => r({erro: "timeout"}), 1500000)), (async () => {
    const W = BdApi.Webpack, St = W.Stores;
    const PC = W.getModule(m => m?.getOrEnsurePrivateChannel && m?.closePrivateChannel);
    const MA = W.getModule(W.Filters.byKeys("fetchMessages", "sendMessage"));
    const a = ${JSON.stringify(a)};
    let ch = a.ch;
    if (!ch) { try { ch = await PC.getOrEnsurePrivateChannel(a.user); } catch (e) { return {erro: "abrir: " + (e?.status ?? e?.message ?? e)}; } }
    try {
      await MA.fetchMessages({channelId: ch, limit: 100});
      for (let i = 0; i < 400; i++) {
        const m = St.MessageStore.getMessages(ch);
        if (!m.hasMoreBefore || !m._array.length) break;
        await MA.fetchMessages({channelId: ch, limit: 100, before: m._array[0].id});
        await new Promise(r => setTimeout(r, 700));
      }
      const m = St.MessageStore.getMessages(ch), me = St.UserStore.getCurrentUser().id;
      const att = m._array.filter(x => x.attachments?.length).map(x => ({id: x.id, quem: x.author.id === me ? "E" : (x.author.globalName || x.author.username), ts: new Date(x.timestamp).toISOString().slice(2,10), texto: (x.content || "").slice(0, 200),
        a: x.attachments.map(t => ({ct: t.content_type || "", fn: t.filename, size: t.size, url: t.url, proxy: t.proxy_url, dur: t.duration_secs}))}));
      const chan = St.ChannelStore.getChannel(ch);
      return {ch, nomes: (chan?.rawRecipients||[]).map(r => r.username).join(", "), total: m._array.length, incompleto: m.hasMoreBefore, att};
    } finally {
      if (!a.ch) { try { PC.closePrivateChannel(ch); } catch {} }
    }
  })()])`);
  if (r.erro) { console.log("FALHOU", a.key, r.erro); fs.writeFileSync(f, JSON.stringify({erro: r.erro, att: []})); continue; }
  fs.writeFileSync(f, JSON.stringify(r));
  console.log(a.key, r.nomes?.slice(0, 30), r.total, "msgs,", r.att.length, "com anexo" + (r.incompleto ? " (incompleto)" : ""));
  await new Promise(r => setTimeout(r, a.ch ? 1500 : 4000));
}
console.log("FIM");
process.exit(0);
